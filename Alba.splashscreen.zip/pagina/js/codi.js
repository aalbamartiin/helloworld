const button = document.getElementById('get-started-gsap');

// Animación al hacer clic
button.addEventListener('click', () => {
    gsap.to(button, {
        duration: 0.2,
        scale: 1.2,
        ease: "power2.out",
        yoyo: true,
        repeat: 1
    });
});

// Animación al pasar el mouse (hover)
button.addEventListener('mouseenter', () => {
    var lineaTiempo = gsap.timeline();
    
    
    lineaTiempo.to(button, {
        duration: 2,
        color: "black",
        ease: "elastic.out(1, 0.3)"
    });
    
       
    lineaTiempo.to(".hero", {
        duration: 2,
        color: "black",
        ease: "elastic.out(1, 0.3)"
    });
    
    
    
    
});

// Restaurar tamaño original al salir del hover
button.addEventListener('mouseleave', () => {
    gsap.to(button, {
        duration: 5,
        color: "white",
        ease: "elastic.out(1, 0.3)"
    });
});








var lt = gsap.timeline();

lt.to("#imagen1", {
    left: 0,
    duration: 2
})


lt.to("#imagen2", {
    left: 0,
    duration: 2
})


lt.to("#imagen3", {
    left: 0,
    duration: 2
})





